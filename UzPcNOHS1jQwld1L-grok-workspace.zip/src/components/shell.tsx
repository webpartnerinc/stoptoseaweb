import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";

const OPEN_START = 11 * 60;
const OPEN_END = 19 * 60 + 30;
const OPEN_DAYS = new Set(["Tue", "Wed", "Thu", "Fri", "Sat"]);
const ORDER = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const NAMES: Record<string, string> = {
  Sun: "Sunday",
  Mon: "Monday",
  Tue: "Tuesday",
  Wed: "Wednesday",
  Thu: "Thursday",
  Fri: "Friday",
  Sat: "Saturday",
};

function bellefontaineNow() {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date());
  const bag: Record<string, string> = {};
  parts.forEach((part) => {
    bag[part.type] = part.value;
  });
  return { day: bag.weekday ?? "Tue", minutes: Number(bag.hour) * 60 + Number(bag.minute) };
}

function nextOpenDay(day: string) {
  const start = ORDER.indexOf(day);
  for (let i = 1; i <= 7; i += 1) {
    const name = ORDER[(start + i) % 7];
    if (OPEN_DAYS.has(name)) return name;
  }
  return "Tue";
}

function paintStatus() {
  const nodes = document.querySelectorAll<HTMLElement>("[data-status]");
  if (!nodes.length) return;
  const now = bellefontaineNow();
  const openToday = OPEN_DAYS.has(now.day);
  const isOpen = openToday && now.minutes >= OPEN_START && now.minutes < OPEN_END;
  let text = "Closed now · opens Tuesday at 11:00 AM";
  if (isOpen) text = "Open now · until 7:30 PM";
  else if (openToday && now.minutes < OPEN_START) text = "Closed now · opens today at 11:00 AM";
  else text = `Closed now · opens ${NAMES[nextOpenDay(now.day)]} at 11:00 AM`;
  nodes.forEach((node) => {
    node.textContent = text;
    node.classList.toggle("is-open", isOpen);
    node.classList.toggle("is-closed", !isOpen);
  });
  document.querySelectorAll<HTMLElement>("[data-day]").forEach((row) => {
    row.classList.toggle("is-today", row.dataset.day === now.day);
  });
}

export function SiteEffects() {
  const path = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    paintStatus();
  }, [path]);

  useEffect(() => {
    const onClick = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const toggle = target.closest("[data-nav-toggle]");
      if (toggle) {
        const nav = document.querySelector("[data-nav]");
        if (!nav) return;
        const open = nav.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        return;
      }
      if (target.closest("[data-nav] a")) {
        document.querySelector("[data-nav]")?.classList.remove("is-open");
        document.querySelector("[data-nav-toggle]")?.setAttribute("aria-expanded", "false");
      }
      const shot = target.closest<HTMLElement>("[data-full]");
      if (shot) {
        const dialog = document.querySelector<HTMLDialogElement>("[data-lightbox]");
        const img = document.querySelector<HTMLImageElement>("[data-lightbox-img]");
        const cap = document.querySelector("[data-lightbox-cap]");
        if (!dialog || !img) return;
        img.src = shot.dataset.full ?? "";
        img.alt = shot.dataset.alt ?? "";
        if (cap) cap.textContent = shot.dataset.alt ?? "";
        dialog.showModal();
        return;
      }
      if (target.closest("[data-lightbox-close]")) {
        document.querySelector<HTMLDialogElement>("[data-lightbox]")?.close();
      }
    };
    const onDialog = (event: MouseEvent) => {
      const dialog = event.currentTarget;
      if (event.target === dialog && dialog instanceof HTMLDialogElement) dialog.close();
    };
    document.addEventListener("click", onClick);
    const dialog = document.querySelector("[data-lightbox]");
    dialog?.addEventListener("click", onDialog);
    return () => {
      document.removeEventListener("click", onClick);
      dialog?.removeEventListener("click", onDialog);
    };
  }, []);

  return null;
}

export function Header({ current }: { current: "home" | "visit" }) {
  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <div className="topbar">
        <div className="wrap topbar-inner">
          <span>909 S Main St, Bellefontaine, Ohio</span>
          <a href="tel:+19375993000">(937) 599-3000</a>
        </div>
      </div>
      <header className="header">
        <div className="wrap header-inner">
          <Link className="brand" to="/">
            <img src="/images/logo.svg" alt="" width={86} height={40} />
            <span className="brand-name">
              <strong>STOP & SEA</strong>
              <span>Fish and more</span>
            </span>
          </Link>
          <button
            className="nav-toggle"
            type="button"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="site-nav"
          >
            Menu
          </button>
          <nav className="nav" id="site-nav" data-nav>
            <Link to="/" aria-current={current === "home" ? "page" : undefined}>
              Home
            </Link>
            <Link to="/visit" aria-current={current === "visit" ? "page" : undefined}>
              Visit
            </Link>
            <a className="btn btn-primary" href="tel:+19375993000">
              Call
            </a>
          </nav>
        </div>
      </header>
    </>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <h2>Stop & Sea</h2>
            <p>Hand-breaded seafood, burgers, and homemade sides in Bellefontaine, Ohio.</p>
          </div>
          <div>
            <h2>Visit</h2>
            <p>
              909 S Main St
              <br />
              Bellefontaine, OH 43311
            </p>
            <p>
              <a href="tel:+19375993000">(937) 599-3000</a>
            </p>
          </div>
          <div>
            <h2>Hours</h2>
            <p>
              Tue–Sat 11:00 AM – 7:30 PM
              <br />
              Sun & Mon closed
            </p>
          </div>
        </div>
        <div className="legal">
          <span>Photos from guests on Google. Hours can change — call ahead.</span>
          <span>© {new Date().getFullYear()} Stop & Sea</span>
        </div>
      </div>
    </footer>
  );
}

export function Lightbox() {
  return (
    <dialog className="lightbox" data-lightbox>
      <img data-lightbox-img alt="" />
      <div className="lightbox-bar">
        <span data-lightbox-cap />
        <button className="lightbox-close" type="button" data-lightbox-close>
          Close
        </button>
      </div>
    </dialog>
  );
}
